<?php

include('requests/other/' . $a . '.php');
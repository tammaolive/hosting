<?php
include('requests/post/' . $a . '.php');
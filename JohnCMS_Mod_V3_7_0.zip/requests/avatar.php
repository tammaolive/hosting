<?php

include('requests/avatar/' . $a . '.php');
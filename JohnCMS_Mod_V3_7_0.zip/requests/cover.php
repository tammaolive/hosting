<?php

include('requests/cover/' . $a . '.php');
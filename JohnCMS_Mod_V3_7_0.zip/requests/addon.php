<?php

include('requests/addon/' . $a . '.php');
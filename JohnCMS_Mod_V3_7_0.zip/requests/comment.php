<?php

include('requests/comment/' . $a . '.php');